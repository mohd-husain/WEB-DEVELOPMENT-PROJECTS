import React, {useContext} from 'react'
import { cartContext } from '../MainContext'
import Header from './Header'
import { Link } from 'react-router'

export default function Cart() {
    let {cart, setCart} =useContext(cartContext)
    return (
        <>
            <section className='grid lg:grid-cols-[60%_auto] grid-cols- gap-10'>
                <div>
                    <div className='flex justify-between shadow-lg p-5'>
                        <h2 className='text-start font-bold text-3xl'>Shopping Cart</h2>
                        <h2 className='text-start font-bold text-3xl'>0 Items</h2>
                    </div>

                    <div className='flex text-start gap-30 text-[15px] mt-20'>
                        <div className=''>PRODUCT DETAILS</div>
                        <div>QUANTITY</div>
                        <div>PRICE</div>
                        <div>TOTAL</div>
                    </div>
                    
                     <div className='flex text-start gap-30 text-[15px] mt-3'>
                        <div className=''>PRODUCT DETAILS</div>
                        <div>QUANTITY</div>
                        <div>PRICE</div>
                        <div>TOTAL</div>
                    </div>

                    <div className='mt-5 text-start text-blue-700 font-bold'>
                        <Link to='/'>Continue Shopping</Link>
                    </div>
                </div>

                <div>
                    <h1 className='text-start font-bold text-3xl mx-2 shadow-lg p-5'>Order Summary</h1>
                    <div className='flex mt-20 justify-between font-bold text-[16px]'>
                        <div>ITEMS 0</div>
                        <div>Rs. 0</div>
                    </div>

                    <div className='text-start mt-5 font-semibold'>SHIPPING</div>
                    <div className='text-start mt-5'>
                        <form>
                            <select className='w-full p-2'>
                                <option>Standard Shipping - Rs. 100</option>
                            </select>
                        </form>
                    </div>

                    <div className='text-start mt-5 font-semibold'>PROMO CODE</div>
                    <div className='mt-5 text-start'>
                        <input type="text" placeholder='Enter You Code' className='w-full'/>
                    </div>
                    <div className='mt-5 text-start shadow-lg p-3'>
                        <button className='bg-red-500 text-white font-bold p-3 rounded'>APPLY</button>
                    </div>
                    <div className='flex mt-20 justify-between font-bold text-[14px]'>
                        <div>TOTAL COST</div>
                        <div>Rs. 0</div>
                    </div>
                    <button className="bg-indigo-500 font-semibold hover:bg-indigo-600 py-3 text-sm text-white uppercase w-full">Checkout</button>

                </div>
            </section>
        </>
    )


}